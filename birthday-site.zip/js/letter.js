/**
 * LETTER.js — renders the friendship letter + generates a downloadable PDF
 * (elegantly formatted, NOT a "certificate" — a genuine letter layout)
 * Uses jsPDF (loaded from CDN in index.html).
 */

const FriendshipLetter = (() => {
  function render() {
    const body = document.getElementById("letter-body");
    if (!body) return;
    body.textContent = fillName(SITE_CONFIG.letterBody);
  }

  let inkRevealed = false;
  function revealInk(onComplete) {
    const body = document.getElementById("letter-body");
    if (!body || inkRevealed) { onComplete && onComplete(); return; }
    inkRevealed = true;
    const full = fillName(SITE_CONFIG.letterBody);
    body.textContent = "";
    let i = 0;
    const speed = full.length > 500 ? 6 : 14; // faster for long letters, still readable
    const typing = setInterval(() => {
      body.textContent += full[i];
      i++;
      if (i >= full.length) { clearInterval(typing); onComplete && onComplete(); }
    }, speed);
  }

  function downloadPDF() {
    const { jsPDF } = window.jspdf || {};
    if (!jsPDF) {
      alert("PDF library failed to load — check your internet connection and try again.");
      return;
    }
    const doc = new jsPDF({ unit: "pt", format: "a4" });
    const pageWidth = doc.internal.pageSize.getWidth();
    const margin = 64;
    const maxWidth = pageWidth - margin * 2;

    // Decorative border
    doc.setDrawColor(240, 200, 110);
    doc.setLineWidth(1.4);
    doc.rect(28, 28, pageWidth - 56, doc.internal.pageSize.getHeight() - 56);

    doc.setFont("times", "italic");
    doc.setFontSize(12);
    doc.setTextColor(120, 100, 60);
    doc.text("A Friendship Letter", margin, 70);

    doc.setFont("times", "bold");
    doc.setFontSize(26);
    doc.setTextColor(40, 30, 70);
    doc.text(`For ${SITE_CONFIG.friendName}`, margin, 105);

    doc.setDrawColor(200, 182, 228);
    doc.setLineWidth(0.6);
    doc.line(margin, 118, pageWidth - margin, 118);

    doc.setFont("times", "normal");
    doc.setFontSize(13.5);
    doc.setTextColor(40, 40, 60);
    const text = fillName(SITE_CONFIG.letterBody);
    const lines = doc.splitTextToSize(text, maxWidth);
    doc.text(lines, margin, 150, { lineHeightFactor: 1.6 });

    doc.setFont("times", "italic");
    doc.setFontSize(10.5);
    doc.setTextColor(140, 140, 160);
    doc.text(
      `Written with love — ${SITE_CONFIG.specialDate} · ${SITE_CONFIG.talkingMonths} months since it all began`,
      margin,
      doc.internal.pageSize.getHeight() - 50
    );

    doc.save(`Friendship-Letter-for-${SITE_CONFIG.friendName.replace(/\s+/g, "-")}.pdf`);
  }

  function init() {
    render();
    document.getElementById("download-letter-btn")?.addEventListener("click", downloadPDF);
  }
  return { init, revealInk };
})();

/* ==================== SPOTIFY / MUSIC CARD ==================== */
const MusicPlayer = (() => {
  function init() {
    const iframe = document.getElementById("spotify-embed");
    if (iframe) iframe.src = SITE_CONFIG.spotifyEmbedUrl;

    const titleEl = document.getElementById("now-playing-title");
    const artistEl = document.getElementById("now-playing-artist");
    if (titleEl) titleEl.textContent = SITE_CONFIG.nowPlaying.title;
    if (artistEl) artistEl.textContent = SITE_CONFIG.nowPlaying.artist;

    const vinyl = document.getElementById("vinyl");
    const playBtn = document.getElementById("music-play-btn");
    let playing = false;
    playBtn?.addEventListener("click", () => {
      playing = !playing;
      vinyl.classList.toggle("is-spinning", playing);
      playBtn.textContent = playing ? "⏸" : "▶️";
      playBtn.setAttribute("aria-label", playing ? "Pause preview" : "Play preview");
      if (playing) SoundManager.startAmbient(); 
    });
  }
  return { init };
})();
