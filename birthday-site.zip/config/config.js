/**
 * ============================================================
 *  CONFIG.js — THE ONLY FILE YOU NEED TO EDIT FOR CONTENT
 * ============================================================
 *  Everything in the site reads from this object: the lock-gate
 *  countdown, the PIN screen, chapter titles, colors, quotes,
 *  music hooks, and images. See /README.md for full instructions.
 * ============================================================
 */

const SITE_CONFIG = {
  // ---- Identity -------------------------------------------------
  friendName: "(name)",              // <-- CHANGE THIS to her real name
  friendNamePossessive: "(name)'s",

  // ---- Key dates --------------------------------------------------
  birthday: "10 December 2005",
  birthDateTime: "2005-12-10T00:00:00",
  // The opening screen counts down to this — her next birthday.
  nextBirthdayDateTime: "2026-12-10T00:00:00",
  turningAge: 21,
  // The countdown/lock unlocks at this exact local date+time.
  // Format: "YYYY-MM-DDTHH:MM:SS"
  unlockDateTime: "2026-12-10T00:00:00",
  // You knew OF each other for this long before you actually became close...
  yearsAcquainted: 3,
  // ...but only really started talking on this date (the actual friendship twist).
  talkingSinceDate: "28 February 2026",
  specialDate: "28 February 2026",
  // Real closeness duration — how long you've actually been talking (since talkingSinceDate)
  talkingMonths: 4,

  // ---- PIN lock (Chapter 1: The Secret Invitation) -----------------
  // 8 digits, DDMMYYYY of the special date above.
  pin: "28022026",

  // ---- Nicknames / hobbies ------------------------------------------
  nicknames: ["Makku 😂", "Thayir Saatham 🍚"],
  hobbies: ["Watching Reels", "Gossiping"],

  // ---- Chapter system (title cards shown between sections) ------------
  chapters: [
    { n: 1, id: "pin",         title: "The Secret Invitation" },
    { n: 2, id: "hero",        title: "The Fairy Kingdom" },
    { n: 3, id: "story",       title: "3 Years Of Almost, 4 Months Of Everything" },
    { n: 4, id: "memories",    title: "Magical Memories" },
    { n: 5, id: "puzzle",      title: "Unlock The Secret Puzzle" },
    { n: 6, id: "giftbox",     title: "The Birthday Gift" },
    { n: 7, id: "cake",        title: "Make A Birthday Wish" },
    { n: 8, id: "celebration", title: "The Grand Celebration" },
    { n: 9, id: "ending",      title: "Until We Meet Someday" }
  ],

  // ---- Movie trailer lines (black screen, one at a time) --------------
  trailerLines: [
    "Three Years Of Almost Being Friends...",
    "Then, One February Day...",
    "Everything Changed...",
    "Four Months. Thousands Of Messages...",
    "Endless Laughs...",
    "One Amazing Best Friend...",
    "One Magical Surprise..."
  ],
  trailerLogoLine: "The Birthday Adventure",

  // ---- Lock-gate copy -------------------------------------------------
  lockGateMessage: "A magical surprise has been prepared especially for you...",
  lockGateSubMessage: "This gift will unlock only on your birthday.",

  // ---- Friendship timeline events (the real story — with a twist) --------
  timeline: [
    { year: "3 Years Ago", title: "We Knew Of Each Other", text: "Same circles, same crowd — but somehow, never really friends. Just familiar faces." },
    { year: "28 Feb 2026", title: "Plot Twist: We Actually Started Talking", text: "Out of nowhere, one random conversation changed everything. No one saw this coming — not even us.", scratch: true },
    { year: "The 4 Months Since", title: "Thousands Of Chats", text: "Endless texts, reels sent at 2am, and gossip sessions that never ended — somehow all packed into just a few months." },
    { year: "Somehow Already", title: "Shared Laughter", text: "Inside jokes only we understand. Makku. Thayir Saatham. It feels like years, not months." },
    { year: "Today", title: "This Very Moment", text: "Celebrating you, exactly as you are." },
    { year: "Forever", title: "The Future", text: "More memories, more laughs, more us — however far apart." }
  ],

  // ---- Fake chat memories (Chapter 4) -----------------------------------
  chatMemories: [
    { from: "me", text: "Makku 😂" },
    { from: "her", text: "😑" },
    { from: "me", text: "Thayir Saatham" },
    { from: "her", text: "😂" },
    { from: "me", text: "guess what happened today" },
    { from: "her", text: "WHAT. TELL ME NOW." },
    { from: "me", text: "sent you 14 reels in a row, no regrets" },
    { from: "her", text: "my thumb hurts from scrolling but ok continue" }
  ],

  // ---- Friendship Letter (plain text, {{NAME}} gets replaced) ------------
  letterBody:
`My dearest {{NAME}},

Here's a twist you probably already know but I still can't get over: we
knew of each other for three whole years before we ever actually talked.
Three years of almost-friendship, wasted.

And then, on one random February day, everything changed. Four months.
That's all it's been. Four months of chats that never end, reels sent at
odd hours, gossip sessions that went way too long, and laughs that made
my stomach hurt — and somehow it already feels like I've known you forever.

Distance never really felt like distance with you — a screen was
always enough to make a bad day better. I hope one day soon we get
to trade the chat bubbles for real hugs.

Thank you for being my Makku, my Thayir Saatham, my constant.
For every "guess what happened," every voice note rant, every
ridiculous meme sent at 1am — thank you.

I hope this year brings you everything you deserve: happiness that
stays, success that finds you without you chasing it, health that
never wavers, and every single dream, coming true, one by one.

Here's to us — three years late, but exactly on time.

Happy Birthday, {{NAME}}.

With all my heart,
Your Best Friend`,

  // ---- Fake Broken Gift twist (Gift chapter) -----------------------------
  giftTwist: {
    shockLine: "😱🧚",
    failLines: ["Hmm, that's not it...", "Wait, let me try again...", "Okay, ONE more try..."],
    successLine: "✨🧚 There we go!",
  },

  // ---- Wish Constellation (Cake chapter) ---------------------------------
  wishConstellation: {
    fairyPrompt: "Before we continue... close your eyes for a moment and make one birthday wish.",
    constellationText: "I hope your wish comes true.",
  },

  // ---- Moon Message (Celebration chapter) --------------------------------
  moonMessage: {
    text: "Happy Birthday {{NAME}}"
  },

  // ---- Completion Whisper (shown only if every secret was found) --------
  completionWhisper: "🧚 Psst... You found every secret. Thank you for exploring every corner of our story.",

  // ---- Scratch-to-Reveal hidden messages ---------------------------------
  scratchReveals: {
    memoryBookNote: "P.S. — I still have the first screenshot of us talking. Never deleting it.",
    greetingWish: "Wishing you a year that finally slows down enough for you to enjoy it.",
    letterHiddenSentence: "Some days you were the only reason I opened my phone at all.",
    featherMessage: "Thank you for staying until the very end. This adventure wouldn't be complete without you."
  },

  // ---- Fake Ending / Fairy Returns / Final Envelope (Secret Ending) ------
  fakeEndingBeat: {
    fairyReturnsLine: "Do you really think our story ends here?",
  },
  finalEnvelope: {
    collecting: ["The Story Book...", "The Memory Book...", "The Greeting Card...", "Every wish you made...", "Every secret you found..."],
    closingLine: "Take good care of these memories...",
  },

  // ---- Movie credits (Chapter 9) ----------------------------------------
  credits: [
    { role: "Directed By", name: "Your Best Friend" },
    { role: "Story", name: "3 Years Of Almost, 4 Months Of Everything" },
    { role: "Starring", name: "{{NAME}}" },
    { role: "Special Thanks", name: "Makku 😂 & Thayir Saatham 🍚" },
    { role: "", name: "See You In The Next Adventure..." }
  ],

  // ---- Final closing message (after credits, before fade to black) -------
  finalWhisper: "Some friendships don't need the same place to become special. Sometimes, a screen is enough to start a story worth remembering.",

  // ---- Spotify (replace with a real playlist/track embed URL) --------
  spotifyEmbedUrl: "https://open.spotify.com/embed/playlist/37i9dQZF1DXcBWIGoYBM5M?utm_source=generator&theme=0",
  nowPlaying: { title: "Our Song", artist: "Replace me in config/config.js" },

  // ---- Loading screen messages ------------------------------------
  loadingMessages: [
    "Preparing a magical surprise...",
    "Collecting happy memories...",
    "Decorating the fairy kingdom...",
    "Lighting birthday candles..."
  ],

  // ---- Easter egg quotes --------------------------------------------
  secretQuote: "\"Some friendships aren't written in blood, they're written in 3am voice notes.\"",

  // ---- Day/night sky gradient stops (scroll-linked atmosphere) -----------
  // Each stop: [topColor, bottomColor]. The site interpolates between
  // these as you scroll from Chapter 1 (morning) to the finale (fireworks).
  skyStops: [
    { label: "morning",   top: "#6bb8e8", bottom: "#c9b98f" },
    { label: "afternoon", top: "#4a96c9", bottom: "#a8c2d9" },
    { label: "sunset",    top: "#5f4899", bottom: "#c98ba3" },
    { label: "night",     top: "#141a45", bottom: "#0B0E2E" },
    { label: "aurora",    top: "#1c2364", bottom: "#241a4d" },
    { label: "fireworks", top: "#05061a", bottom: "#0B0E2E" }
  ],

  // ---- Per-chapter music slots ---------------------------------------
  // Every scene points at a track key loaded in js/audio.js. Right now
  // most point at the same two placeholder tracks (swap-ready) — replace
  // any value here with a new track key once you've added more audio
  // files (see js/audio.js `files` map + README for how to add tracks).
  music: {
    hero:         "ambient",
    storybook:    "ambient",
    memorybook:   "ambient",
    timeline:     "ambient",
    chat:         "ambient",
    puzzle:       "ambient",
    gift:         "ambient",
    greeting:     "ambientAct3",
    cake:         "ambientAct3",
    celebration:  "ambientAct3",
    music:        "ambientAct3",
    credits:      "ambientAct3",
    secretending: "ambientAct3"
  },

  // ---- Theme overrides — change colors/fonts here without touching CSS ----
  // Any value you set here overrides the CSS default at runtime.
  // Leave a value blank ("") to keep the CSS default.
  theme: {
    colors: {
      "--c-gold": "",
      "--c-lavender": "",
      "--c-pink": "",
      "--c-sky": ""
    },
    fonts: {
      "--font-display": "",
      "--font-body": "",
      "--font-ui": ""
    }
  }
};

// Helper: fills {{NAME}} tokens anywhere in strings
function fillName(str) {
  return str.replaceAll("{{NAME}}", SITE_CONFIG.friendName);
}

// Helper: allow ?preview=true or localStorage flag to skip the lock-gate
// during development/testing, without touching the real unlock date.
function isPreviewMode() {
  try {
    const params = new URLSearchParams(window.location.search);
    if (params.get("preview") === "true") {
      localStorage.setItem("bday_preview", "1");
    }
    return localStorage.getItem("bday_preview") === "1";
  } catch (e) {
    return false;
  }
}
